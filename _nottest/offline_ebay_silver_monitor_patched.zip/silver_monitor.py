# silver_monitor.py
from __future__ import annotations

import time
import random
from datetime import datetime
from typing import List
import re

import config

from html_loader import discover_html_files, load_html_file, delete_processed_files
from ebay_search_parser import parse_ebay_search_html
from price_store import load_store, save_store, capture_updates
from numismatic_rules import detect_coin_identity, make_benchmark_key
from hit_engine import evaluate_listings, select_hits
from state_store import load_seen_hits, save_seen_hits, split_new_hits
from email_format import build_email_subject, build_email_body
from emailer import send_email
from console_tables import print_hit_miss_table
from silver_math import extract_quantity_from_title



# ----------------------------------------------------------------------------
# Compatibility helper: older pipelines sometimes pass Listing directly,
# newer ones pass wrapper objects with a `.listing` attribute.
# ----------------------------------------------------------------------------
def _unwrap_listing(obj):
    return getattr(obj, 'listing', obj)

# -----------------------------
# Disqualifiers
# -----------------------------

_HARD_DISQUALIFY_RE = re.compile(
    r"(?i)\b(?:holed|hole|pierced|drilled|copy|replica|clad|plated)\b"
)

_ACCESSORY_DISQUALIFY_RE = re.compile(
    r"(?i)\b(?:dansco|whitman|folder|album|coin\s*book|no\s*coins?)\b"
)


# -----------------------------
# Helpers
# -----------------------------

def _now_ts() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _filename_is_silver(name: str) -> bool:
    n = name.lower()
    return any(k in n for k in config.SILVER_FILENAME_KEYWORDS)


def _earliest_time_str(hits) -> str:
    times = [
        getattr(_unwrap_listing(e), "end_time_ts", None)
        for e in hits
        if getattr(_unwrap_listing(e), "end_time_ts", None) is not None
    ]
    if not times:
        return datetime.now().strftime("%I:%M %p")
    return datetime.fromtimestamp(min(times)).strftime("%I:%M %p")


def _dedupe_key(lst) -> str:
    if getattr(lst, "item_id", None):
        return f"itm:{lst.item_id}"
    if lst.url:
        return f"url:{lst.url.split('?',1)[0]}"
    return f"title:{lst.title.lower()}"


def _dedupe_listings(listings: List):
    seen = set()
    out = []
    for lst in listings:
        k = _dedupe_key(lst)
        if k in seen:
            continue
        seen.add(k)
        out.append(lst)
    return out


# -----------------------------
# Core run
# -----------------------------

def run_once(min_qty: int | None, blacklist: List[str]):
    html_paths = discover_html_files(config.HTML_FOLDER_PATH, _filename_is_silver)

    if not html_paths:
        return dict(had_files=False, evaluated=[], hits=[], new_hits=[], files_found=0, parsed=0)

    listings = []
    processed = []

    for path in html_paths:
        fname, html = load_html_file(path)
        parsed = parse_ebay_search_html(fname, html)
        if parsed:
            processed.append(path)
        listings.extend(parsed)

    listings = _dedupe_listings(listings)

    filtered = []
    for lst in listings:
        if _HARD_DISQUALIFY_RE.search(lst.title or ""):
            continue
        if _ACCESSORY_DISQUALIFY_RE.search(lst.title or ""):
            continue
        if min_qty is not None:
            q = extract_quantity_from_title(lst.title)
            if q is not None and q < min_qty:
                continue
        filtered.append(lst)

    evaluated = evaluate_listings(filtered, config)
    hits = select_hits(evaluated)

    seen = load_seen_hits()
    keys = {_dedupe_key(_unwrap_listing(e)) for e in hits}
    new_keys, merged = split_new_hits(keys, seen)
    new_hits = [e for e in hits if _dedupe_key(_unwrap_listing(e)) in new_keys]
    save_seen_hits(merged)

    if getattr(config, "DELETE_PROCESSED_HTML", False):
        delete_processed_files(processed)

    return dict(
        had_files=True,
        evaluated=evaluated,
        hits=hits,
        new_hits=new_hits,
        files_found=len(html_paths),
        parsed=len(listings),
    )


# -----------------------------
# Main loop
# -----------------------------

def main():
    print("\n============================================================")
    print("  EBAY OFFLINE SILVER MONITOR")
    print("============================================================\n")

    min_qty = config.DEFAULT_MIN_QUANTITY
    blacklist = list(config.DEFAULT_BLACKLIST or [])

    while True:
        try:
            result = run_once(min_qty, blacklist)

            print(
                f"[{_now_ts()}] Files: {result['files_found']} | "
                f"Listings: {result['parsed']} | "
                f"HITs: {len(result['hits'])} | "
                f"New: {len(result['new_hits'])}"
            )

            print_hit_miss_table(result["evaluated"])

            if result["new_hits"] and config.EMAIL_ENABLED:
                earliest = _earliest_time_str(result["new_hits"])
                subject = build_email_subject(earliest, len(result["new_hits"]))
                body = build_email_body(result["new_hits"], config)
                send_email(subject, body)
                print(f"EMAIL: sent ({len(result['new_hits'])} new)")
            else:
                print("EMAIL: (no new HITs)")

        except KeyboardInterrupt:
            print("\n[EXIT] Monitor stopped.")
            break
        except Exception as e:
            print(f"[ERROR] {e}")

        sleep_sec = config.DEFAULT_CHECK_INTERVAL_MIN * 60
        time.sleep(max(10.0, sleep_sec))


if __name__ == "__main__":
    main()