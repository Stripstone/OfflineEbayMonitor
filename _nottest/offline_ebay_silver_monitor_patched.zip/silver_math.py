# silver_math.py
from __future__ import annotations

import re
from typing import Any, Dict, Optional, List

# ============================================================
# Quantity extraction (PUBLIC API)
# ============================================================

_WORD_NUMS = {
    "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
    "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
    "dozen": 12, "pair": 2
}

_NUM_RE = re.compile(r"\b(\d{1,3})\b")
_YEAR_RE = re.compile(r"\b(18|19|20)\d{2}\b")
_PERCENT_RE = re.compile(r"\b\d{1,3}\s*%")
_GRADE_RE = re.compile(r"\b(ms|pf|pr|au|xf|vf|vg|f)\s*\d{1,2}\b", re.IGNORECASE)

_FACE_RE = re.compile(r"\$(\d+)\s*face", re.IGNORECASE)
_ROLL_RE = re.compile(r"\broll\b", re.IGNORECASE)

_HALF_DOLLAR_TYPES = {
    "Walking Liberty Half Dollar",
    "Franklin Half Dollar",
    "Kennedy Half Dollar",
    "Barber Half Dollar",
}


def extract_quantity_from_title(title: str) -> Optional[int]:
    if not title:
        return None

    t = title.lower()

    for word, num in _WORD_NUMS.items():
        if re.search(rf"\b{word}\b", t):
            return num

    candidates: List[int] = []
    for m in _NUM_RE.finditer(t):
        n = int(m.group(1))

        if _YEAR_RE.search(m.group(0)):
            continue
        if _PERCENT_RE.search(m.group(0)):
            continue
        if _GRADE_RE.search(t[max(0, m.start()-6):m.end()+6]):
            continue

        candidates.append(n)

    return max(candidates) if candidates else None


# ============================================================
# Quantity normalization
# ============================================================

def _infer_face_or_roll_qty(title: str, coin_type: str) -> Optional[int]:
    if coin_type not in _HALF_DOLLAR_TYPES:
        return None

    m = _FACE_RE.search(title)
    if m:
        return int(m.group(1)) * 2

    if _ROLL_RE.search(title.lower()):
        return 20

    return None


def _normalize_qty(extracted: Optional[int], title: str, coin_type: str) -> int:
    if isinstance(extracted, int) and extracted > 0:
        return extracted

    inferred = _infer_face_or_roll_qty(title, coin_type)
    if inferred:
        return inferred

    return 1


# ============================================================
# Core calculation API (PUBLIC)
# ============================================================

def calc_silver(listing: Any, config: Any | None = None) -> Dict[str, Any]:
    # Allow older call sites that didn\'t pass config
    if config is None:
        import config as _cfg
        config = _cfg

    title = listing.title or ""
    coin_type = getattr(listing, "coin_type", "")

    extracted_qty = getattr(listing, "quantity", None)
    quantity = _normalize_qty(extracted_qty, title, coin_type)

    oz_per_coin = float(getattr(listing, "oz_per_coin", 0.0))
    total_oz = oz_per_coin * quantity

    melt_value = total_oz * config.SPOT_PRICE
    pawn_value = melt_value * (config.PAWN_PAYOUT_PCT / 100.0)

    current_total = float(getattr(listing, "total_price", 0.0))

    profit = pawn_value - current_total
    margin_pct = (profit / pawn_value * 100.0) if pawn_value > 0 else 0.0

    # --- SAFE CONFIG FALLBACK ---
    target_margin_min = getattr(config, "TARGET_MARGIN_PCT_MIN", None)
    if target_margin_min is None:
        target_margin_min = getattr(config, "TARGET_MARGIN_PCT", 0.0)

    rec_max_total = pawn_value * (1 - float(target_margin_min) / 100.0)

    return {
        "quantity": quantity,
        "oz_per_coin": oz_per_coin,
        "total_oz": total_oz,
        "melt_value": melt_value,
        "pawn_value": pawn_value,
        "profit": profit,
        "margin_pct": margin_pct,
        "rec_max_total": rec_max_total,
    }
