# numismatic_rules.py

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional, Tuple, List
import re


@dataclass(frozen=True)
class NumismaticOverride:
    coin_type: str
    year: int
    mint: str
    display_name: str


_YEAR_RE = re.compile(r"\b(17\d{2}|18\d{2}|19\d{2}|20\d{2})\b")
_YEAR_RANGE_RE = re.compile(r"\b(17\d{2}|18\d{2}|19\d{2}|20\d{2})\s*[-–—]\s*(17\d{2}|18\d{2}|19\d{2}|20\d{2})\b")

# Compact mint tokens (handles " 1900 O ", "-S", "1884-CC", and "1906D" etc.)
_MINT_TOKEN_RE = re.compile(r"(?i)\b(cc|[dosp])\b")
_GLUE_YEAR_MINT_RE = re.compile(r"(?i)\b(17\d{2}|18\d{2}|19\d{2}|20\d{2})\s*[-,./]?\s*(cc|[dosp])\b")

_DEFAULT_MINT = "P"


def _norm_mint(m: str) -> str:
    m = (m or "").strip().upper().replace(" ", "")
    if not m:
        return _DEFAULT_MINT
    if m == "PHILADELPHIA":
        return "P"
    if m in {"D", "S", "O", "P", "CC"}:
        return m
    return m


# Spelled-out mint locations (fallback when compact mint mark isn't present)
_MINT_WORD_PATTERNS: list[tuple[re.Pattern, object]] = [
    (re.compile(r"(?i)\bcarson\s*city\b"), "CC"),
    (re.compile(r"(?i)\bnew\s*orleans\b"), "O"),
    (re.compile(r"(?i)\bsan\s*francisco\b"), "S"),
    (re.compile(r"(?i)\bdenver\b"), "D"),
    (re.compile(r"(?i)\bphiladelphia\b|\bphilly\b"), "P"),
    (re.compile(r"(?i)\b(cc|[dso])\s*mint\b"), lambda m: m.group(1).upper()),
    (re.compile(r"(?i)\bno\s+mint\s+mark\b"), "P"),
]


def _mint_from_words(title: str) -> Optional[str]:
    tl = (title or "").strip()
    if not tl:
        return None
    for pat, code in _MINT_WORD_PATTERNS:
        m = pat.search(tl)
        if not m:
            continue
        if callable(code):
            try:
                return _norm_mint(code(m))
            except Exception:
                continue
        return _norm_mint(str(code))
    return None


def _mint_near_year(title: str, year: int) -> str:
    t = title or ""
    y = str(int(year))

    # 1) Year+mint glued / hyphen / punctuation
    for m in _GLUE_YEAR_MINT_RE.finditer(t):
        if m.group(1) == y:
            return _norm_mint(m.group(2))

    # 2) Mint token in a small window around the year
    idx = t.find(y)
    if idx != -1:
        window = t[max(0, idx - 8): min(len(t), idx + len(y) + 12)]
        mt = _MINT_TOKEN_RE.search(window)
        if mt:
            return _norm_mint(mt.group(1))

    # 3) Spelled-out mint location (New Orleans, Carson City, etc.)
    mw = _mint_from_words(t)
    if mw:
        return mw

    # 4) Default
    return _DEFAULT_MINT


def _is_counterfeit(text_lower: str) -> bool:
    return any(k in text_lower for k in ("replica", "copy", "reproduction", "fantasy"))


# ---- Coin coverage (single-coin identity) ----
_COIN_PATTERNS: list[tuple[re.Pattern, str]] = [
    (re.compile(r"(?i)\bmorgan\b"), "Morgan Dollar"),
    (re.compile(r"(?i)\bpeace\b"), "Peace Dollar"),
    (re.compile(r"(?i)\bseated\b.*\bliberty\b.*\bdollar\b"), "Seated Liberty Dollar"),

    (re.compile(r"(?i)\bbarber\b.*\bhalf\b|\bbarber\s*half\b|\bliberty\s*head\b.*\bhalf\b"), "Barber Half"),
    (re.compile(r"(?i)\bseated\b.*\bliberty\b.*\bhalf\b"), "Seated Liberty Half"),
    (re.compile(r"(?i)\bwalking\b.*\bliberty\b.*\bhalf\b|\bwalker\b.*\bhalf\b"), "Walking Liberty Half"),

    # Melt-eligible halves (not “numismatic” policy-wise, but must be identifiable)
    (re.compile(r"(?i)\b(?:ben(?:jamin)?\s+)?franklin\b.*\bhalf\b|\bfranklin\b.*\b50\s*(?:c|¢)\b|\bfranklin\s*half\b"),
     "Franklin Half"),
    (re.compile(r"(?i)\bkennedy\b.*\bhalf\b|\bjfk\b.*\bhalf\b|\bjohn\s*f\.?\s*kennedy\b|\bkennedy\b.*\b50\s*(?:c|¢)\b"),
     "Kennedy Half"),
]

# ---- Type-only coverage (lots/sets routing) ----
_SILVER_TYPE_PATTERNS: list[tuple[re.Pattern, str]] = [
    (re.compile(r"(?i)\bmorgan\b"), "Morgan Dollar"),
    (re.compile(r"(?i)\bpeace\b"), "Peace Dollar"),
    (re.compile(r"(?i)\bbarber\b"), "Barber Half"),
    (re.compile(r"(?i)\bwalking\b.*\bliberty\b|\bwalker\b"), "Walking Liberty Half"),
    (re.compile(r"(?i)\bseated\b.*\bliberty\b.*\bhalf\b"), "Seated Liberty Half"),
    (re.compile(r"(?i)\bseated\b.*\bliberty\b.*\bdollar\b"), "Seated Liberty Dollar"),
    (re.compile(r"(?i)\bfranklin\b"), "Franklin Half"),
    (re.compile(r"(?i)\bkennedy\b|\bjfk\b|\bjohn\s*f\.?\s*kennedy\b"), "Kennedy Half"),
]


def _valid_date_range(coin_type: str, year: int) -> bool:
    if coin_type == "Morgan Dollar":
        return 1878 <= year <= 1921
    if coin_type == "Peace Dollar":
        return 1921 <= year <= 1935
    if coin_type == "Barber Half":
        return 1892 <= year <= 1915
    if coin_type == "Seated Liberty Half":
        return 1839 <= year <= 1891
    if coin_type == "Seated Liberty Dollar":
        return 1840 <= year <= 1873
    if coin_type == "Walking Liberty Half":
        return 1916 <= year <= 1947
    if coin_type == "Franklin Half":
        return 1948 <= year <= 1963
    if coin_type == "Kennedy Half":
        # Conservative: only 1964 is 90%
        return year == 1964
    return False


def detect_coin_identity(title: str) -> Optional[Tuple[str, int, str]]:
    """
    Single-coin identity (coin_type, year, mint).
    Conservative by design: returns None on lots/sets/ambiguous titles.
    """
    try:
        t = (title or "").strip()
        if not t:
            return None

        coin_type = None
        for pat, ctype in _COIN_PATTERNS:
            if pat.search(t):
                coin_type = ctype
                break
        if not coin_type:
            return None

        tl = t.lower()
        if _is_counterfeit(tl):
            return None

        if _YEAR_RANGE_RE.search(t):
            return None

        ym = _YEAR_RE.search(t)
        if not ym:
            return None
        year = int(ym.group(1))

        # IMPORTANT: do not reject proof Franklins/JFKs at identity stage
        if "proof" in tl and coin_type not in {"Franklin Half", "Kennedy Half"}:
            return None

        if not _valid_date_range(coin_type, year):
            return None

        mint = _mint_near_year(t, year)
        return coin_type, year, mint
    except Exception:
        return None


def detect_silver_type(title: str) -> Optional[str]:
    """Type-only detector for lots/sets routing."""
    try:
        t = (title or "").strip()
        if not t:
            return None
        tl = t.lower()
        if _is_counterfeit(tl):
            return None
        for pat, stype in _SILVER_TYPE_PATTERNS:
            if pat.search(t):
                return stype
        return None
    except Exception:
        return None


def detect_keydate_mentions(text: str) -> List[Tuple[str, int, str]]:
    """
    Multi-mention extractor for LOT-PROS: returns list of (coin_type, year, mint).
    Intended for PROS only (never EMA).
    """
    out: List[Tuple[str, int, str]] = []
    try:
        t = (text or "").strip()
        if not t:
            return out

        coin_type = None
        for pat, ctype in _COIN_PATTERNS:
            if pat.search(t):
                coin_type = ctype
                break
        if not coin_type:
            return out

        tl = t.lower()
        if _is_counterfeit(tl):
            return out
        if "proof" in tl and coin_type not in {"Franklin Half", "Kennedy Half"}:
            return out

        for ym in _YEAR_RE.finditer(t):
            year = int(ym.group(1))
            if not _valid_date_range(coin_type, year):
                continue
            mint = _mint_near_year(t, year)
            out.append((coin_type, year, mint))

        # dedupe
        seen = set()
        deduped: List[Tuple[str, int, str]] = []
        for ct, y, m in out:
            k = (ct, int(y), _norm_mint(m))
            if k in seen:
                continue
            seen.add(k)
            deduped.append(k)
        return deduped
    except Exception:
        return []


def make_benchmark_key(coin_type: str, year: int, mint: str) -> str:
    try:
        return f"{str(coin_type)}|{int(year)}|{_norm_mint(str(mint))}"
    except Exception:
        return f"{coin_type}|{year}|{mint}"


def check_numismatic_override(*args: Any, **kwargs: Any) -> Optional[NumismaticOverride]:
    title = None
    try:
        if args:
            a0 = args[0]
            if isinstance(a0, str):
                title = a0
            elif hasattr(a0, "title"):
                title = getattr(a0, "title", None)
        if title is None:
            title = kwargs.get("title")

        ident = detect_coin_identity(title or "")
        if not ident:
            return None

        coin_type, year, mint = ident
        display = f"{coin_type} {year}-{mint}"
        return NumismaticOverride(coin_type=coin_type, year=year, mint=mint, display_name=display)
    except Exception:
        return None
