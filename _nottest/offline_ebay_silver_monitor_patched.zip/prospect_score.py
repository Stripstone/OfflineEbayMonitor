"""prospect_score.py

PROSPECT SCORE (PCX) — PROS gate (non-UX)

Purpose:
- Score a numismatic listing's "mispriced / unnoticed" potential using only
  fields available in offline search HTML parsing (title, bids, time_left, prices).
- Do NOT change UX output directly. This module only returns a score + reasons.

Design constraints:
- No network calls.
- No photo analysis.
- Pure function style: deterministic given inputs.
- User-tunable via config.py.
"""

from __future__ import annotations

from dataclasses import dataclass
import re
from typing import List, Tuple, Optional, Any

import config


@dataclass
class ProspectScore:
    score: int
    reasons: List[str]


_RE_BIDS = re.compile(r"\b(\d+)\s*bids?\b", re.I)


def _title_has_any(title: str, needles: List[str]) -> bool:
    t = (title or "").lower()
    for n in needles or []:
        n2 = str(n).strip().lower()
        if not n2:
            continue
        if n2 in t:
            return True
    return False


def _title_matches_any_regex(title: str, patterns: List[str]) -> bool:
    s = title or ""
    for pat in patterns or []:
        try:
            if re.search(str(pat), s, flags=re.I):
                return True
        except Exception:
            continue
    return False



def _minutes_left(listing: Any, tleft: str) -> Optional[int]:
    """Best-effort minutes-left.
    Prefer listing.end_time_ts when present; otherwise parse common 'Xm left' strings.
    """
    end_ts = getattr(listing, "end_time_ts", None)
    try:
        if end_ts is not None:
            import time as _time
            sec = float(end_ts) - _time.time()
            if sec >= 0:
                return int(sec // 60)
    except Exception:
        pass

    s = (tleft or "").lower()
    m = re.search(r"(\d{1,4})\s*m\b", s)
    if m:
        try:
            return int(m.group(1))
        except Exception:
            return None
    m = re.search(r"(\d{1,3})\s*min\b", s)
    if m:
        try:
            return int(m.group(1))
        except Exception:
            return None
    return None


def _score_from_values(*, title: str, current_total: float, fmv_floor: float, dealer_value: float, config=None) -> float:
    score = 0.0

    # Favor listings priced at or below floor values (mispricing signal)
    if current_total <= fmv_floor:
        score += 35.0
    elif current_total <= (fmv_floor * 1.05):
        score += 20.0

    # Dealer-margin signal (guaranteed exit floor)
    dealer_margin_pct = 0.0
    if current_total > 0:
        dealer_margin_pct = (dealer_value - current_total) / current_total * 100.0

    # If config provides a minimum dealer margin for PROS, reflect it as score.
    min_margin = getattr(config, "PROS_MIN_DEALER_MARGIN_PCT", 10.0) if config is not None else 10.0
    if dealer_margin_pct >= min_margin:
        score += 20.0
        # extra credit for bigger margins
        score += min(25.0, max(0.0, dealer_margin_pct - min_margin) * 0.5)

    # High-grade language bonus (your strategy: capture upside via PROS, not EMA)
    high_grade_re = re.compile(r"\b(MS\s*6[0-9]|MS\s*70|MS\-?6[0-9]|MS\-?70|UNC|BU|GEM|FBL|DCAM|CAMEO|PL|DMPL|PROOF)\b", re.I)
    if high_grade_re.search(title):
        score += 15.0

    # Clean/holed/etc penalty
    problem_re = re.compile(r"\b(HOLED|CLEANED|DAMAGE|DAMAGED|BENT|SCRATCH|POLISHED|HARSH)\b", re.I)
    if problem_re.search(title):
        score -= 25.0

    return max(0.0, score)

def score_prospect(listing: Listing, config=None, *, fmv_floor: float | None = None, dealer_value: float | None = None) -> float:
    """Return a PROS score for a listing.

    Compatibility goals:
    - Accepts the historical call pattern: score_prospect(listing, config)
    - Also accepts explicit overrides: score_prospect(listing, fmv_floor=..., dealer_value=...)
    - Pulls fmv_floor / dealer_value from listing.silver_calc when present
    """
    # Pull defaults from the computed silver_calc (preferred)
    sc = getattr(listing, "silver_calc", None) or {}
    if fmv_floor is None:
        fmv_floor = float(sc.get("fmv_floor") or 0.0)
    if dealer_value is None:
        dealer_value = float(sc.get("dealer_value") or sc.get("dealer_payout") or 0.0)

    # Legacy keys that may exist in older calc payloads
    current_total = float(sc.get("current_total") or sc.get("total_price") or getattr(listing, "total_price", 0.0) or 0.0)

    # Guard: If we don't have the basic valuation components, there is no meaningful PROS score.
    if fmv_floor <= 0.0 or dealer_value <= 0.0:
        return 0.0

    # Delegate to the existing internal scorer (keeps your tuned weights intact)
    return _score_from_values(
        title=getattr(listing, "title", "") or "",
        current_total=current_total,
        fmv_floor=fmv_floor,
        dealer_value=dealer_value,
        config=config,
    )
