# hit_engine.py
from __future__ import annotations
from typing import List, Any

from silver_math import calc_silver
from prospect_score import score_prospect


def evaluate_listings(listings: List[Any], config: Any) -> List[Any]:
    """
    Evaluate listings and attach:
      - silver_calc
      - is_hit
      - is_prospect
    """
    evaluated = []

    for lst in listings:
        # Core silver math
        silver_calc = calc_silver(lst, config)
        lst.silver_calc = silver_calc

        # HIT = melt-positive
        lst.is_hit = silver_calc.get("profit", 0.0) >= 0.0

        # PROS scoring
        # IMPORTANT: score_prospect reads from listing + listing.silver_calc
        # Do NOT pass silver_calc as a kwarg (signature does not allow it)
        lst.is_prospect = score_prospect(
            listing=lst,
            config=config,
        )

        evaluated.append(lst)

    return evaluated


def select_hits(evaluated: List[Any]) -> List[Any]:
    """
    Select items that should appear in console/email:
      - HITs (melt-positive)
      - PROS (numismatic prospects)
    """
    hits = []
    for e in evaluated:
        if getattr(e, "is_hit", False) or getattr(e, "is_prospect", False):
            hits.append(e)
    return hits
