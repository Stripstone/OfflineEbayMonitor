# email_format.py
from __future__ import annotations
from datetime import datetime
from typing import List, Any



# ----------------------------------------------------------------------------
# Compatibility helper: sometimes we receive Listing directly instead of a
# wrapper object with a `.listing` attribute.
# ----------------------------------------------------------------------------
def _unwrap_listing(obj):
    return getattr(obj, 'listing', obj)

def build_email_subject(earliest_time: str, new_count: int) -> str:
    return f"{earliest_time} Offline eBay Silver HITS ({new_count} new)"


def build_email_body(hits: List[Any], config: Any) -> str:
    lines: List[str] = []

    lines.append("EBAY OFFLINE SILVER HITS")
    lines.append("=" * 32)
    lines.append(
        f"Spot: ${config.SPOT_PRICE:.2f} | Pawn: {config.PAWN_PAYOUT_PCT:.1f}%"
    )
    lines.append(f"Bid offset: ${config.BID_OFFSET:.2f}")
    lines.append(
        f"Target margin: {config.TARGET_MARGIN_PCT_MIN:.1f}%–{config.TARGET_MARGIN_PCT_MAX:.1f}%"
    )
    lines.append(f"Max time left: {config.MAX_TIME_LEFT_HOURS:.2f} hours")
    lines.append("")
    lines.append(f"Total HITs: {len(hits)}")
    lines.append("-" * 40)

    for idx, e in enumerate(hits, start=1):
        lst = _unwrap_listing(e)
        sc = e.silver_calc or {}

        is_pros = bool(sc.get("is_prospect"))

        lines.append(f"#{idx} [{lst.page_name}]")
        lines.append(f"Title: {lst.title}")

        # -------------------------------
        # NUMISMATIC / PROS OVERRIDE BLOCK
        # -------------------------------
        if is_pros:
            dealer_payout = float(sc.get("dealer_value", 0.0))
            current_total = float(lst.total_price)

            dealer_profit = dealer_payout - current_total
            dealer_margin = (
                (dealer_profit / dealer_payout) * 100.0
                if dealer_payout > 0
                else 0.0
            )

            lines.append(
                f"<<<<Numismatic override: {sc.get('numismatic_label')}"
            )
            lines.append(
                f"Est. dealer payout (@{config.NUMISMATIC_PAYOUT_PCT:.1f}%): "
                f"${dealer_payout:.2f} "
                f"(est. profit: ${dealer_profit:.2f}, "
                f"{dealer_margin:.1f}% margin vs current)"
            )
            lines.append(
                f"FMV floor (G–VG): ${sc.get('fmv_floor', 0.0):.2f} | "
                f"Source: {sc.get('fmv_source', 'Unknown')}"
            )

        # -------------------------------
        # MELT / HIT ECONOMICS
        # -------------------------------
        pawn_value = float(sc.get("pawn_value", 0.0))
        current_total = float(lst.total_price)

        current_profit = pawn_value - current_total
        current_margin = (
            (current_profit / pawn_value) * 100.0
            if pawn_value > 0
            else 0.0
        )

        lines.append(
            f"Current Profit: ${current_profit:.2f} "
            f"({current_margin:.1f}% margin)"
        )
        lines.append(
            f"RecMaxTotal (incl. ship): ${sc.get('rec_max_total', 0.0):.2f}"
        )
        lines.append(
            f"Current Total: ${current_total:.2f} "
            f"(item ${lst.item_price:.2f} + ship ${lst.shipping_price:.2f})"
        )

        qty = sc.get("quantity", lst.quantity or 1)
        lines.append(
            f"Qty: {qty} | oz/coin: {sc.get('oz_per_coin', 0.0):.5f} | "
            f"Total oz: {sc.get('total_oz', 0.0):.2f}"
        )
        lines.append(
            f"Melt: ${sc.get('melt_value', 0.0):.2f} | "
            f"Pawn payout: ${pawn_value:.2f}"
        )
        lines.append(f"Time left: {lst.time_left}")
        lines.append(
            f"Links: {lst.url} | {lst.search_url}"
        )
        lines.append("")

    lines.append(
        f"Generated at: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    )

    return "\n".join(lines)