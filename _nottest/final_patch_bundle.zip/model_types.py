"""
model_types.py

Authoritative shared dataclasses for the Offline eBay Silver Monitor.

Contract:
- No "..."/truncation.
- Keep names stable: Listing, HitRow.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional


@dataclass(slots=True)
class Listing:
    # Provenance
    page_name: str                     # source HTML filename
    item_id: Optional[str]             # eBay item id if present
    url: str                           # canonical listing URL if present
    title: str

    # Money
    price: float                       # item price (USD)
    shipping: float                    # shipping price (USD, 0 if free/unknown)
    total: float                       # price + shipping (USD)

    # Quantity heuristics
    qty: int = 1

    # Time
    time_left_text: str = ""           # raw time-left string if available
    ends_at: Optional[datetime] = None # parsed absolute end time if available


@dataclass(slots=True)
class HitRow:
    title: str
    hit_miss: str              # "HIT" or "Miss" (or "PROS" if you extend later)
    found_pct: float           # 0-100 (page-sanity / confidence; keep 0 if unknown)
    profit: float              # current profit at current total
    recmax_total: float        # recommended maximum TOTAL (incl ship)
    total: float               # current total (incl ship)
    qty: int
    time_left: str

    # For email + debugging
    page_name: str = ""
    url: str = ""
    item_id: str = ""
    melt: float = 0.0
    pawn_payout: float = 0.0
    oz_per_coin: float = 0.0
    total_oz: float = 0.0
