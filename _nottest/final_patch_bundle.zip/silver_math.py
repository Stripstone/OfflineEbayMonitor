"""
silver_math.py

Focused "melt + payout + recommended max" math.
This module is intentionally conservative and simple.

IMPORTANT:
- This file exposes calc_silver(listing, spot, pawn_pct, target_margin_pct)
  because other modules import it by that name.
"""
from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Optional, Tuple

from model_types import Listing

# --- Silver content (troy oz) approximations for common US coins ---
OZ_MORGAN_PEACE = 0.77344          # 90% of 0.8594 ASW (approx); conservative
OZ_HALF_90 = 0.36169               # 90% half dollar (Franklin/Walking/etc.)
OZ_HALF_40 = 0.14790               # 40% Kennedy half

# Spot assumptions are supplied by config; do not hardcode spot here.

@dataclass(frozen=True, slots=True)
class SilverResult:
    oz_per_coin: float
    total_oz: float
    melt: float
    pawn_payout: float
    profit: float
    recmax_total: float

# --- detection heuristics ---
_RE_MORGAN = re.compile(r"\bmorgan\b", re.I)
_RE_PEACE = re.compile(r"\bpeace\b", re.I)
_RE_HALF = re.compile(r"\bhalf\b|\b50c\b|\b50¢\b", re.I)
_RE_FRANKLIN = re.compile(r"\bfranklin\b", re.I)
_RE_WALKING = re.compile(r"\bwalking\b|\bwalker\b", re.I)
_RE_KENNEDY = re.compile(r"\bkennedy\b|\bjfk\b", re.I)
_RE_40 = re.compile(r"\b40%\b|\b40 percent\b|\b(1965|1966|1967|1968|1969)\b", re.I)
_RE_90 = re.compile(r"\b90%\b|\b90 percent\b|1964", re.I)

def detect_oz_per_coin(title: str) -> Optional[float]:
    """
    Returns oz per coin for supported silver items, else None.
    Conservative: if ambiguous, return None so we don't spam false results.
    """
    t = title or ""
    if _RE_MORGAN.search(t) or re.search(r"\b\$1\b", t) and "morgan" in t.lower():
        return OZ_MORGAN_PEACE
    if _RE_PEACE.search(t):
        return OZ_MORGAN_PEACE

    # halves
    if _RE_HALF.search(t) or _RE_FRANKLIN.search(t) or _RE_WALKING.search(t) or _RE_KENNEDY.search(t):
        # prefer explicit 40% signal
        if _RE_40.search(t) and not _RE_90.search(t):
            return OZ_HALF_40
        # default to 90% for Franklin/Walking/Barber/etc; Kennedy 1964 will match 90
        return OZ_HALF_90

    return None

def calc_silver(listing: Listing, spot: float, pawn_pct: float, target_margin_pct: float) -> Optional[SilverResult]:
    oz_per = detect_oz_per_coin(listing.title)
    if oz_per is None:
        return None
    qty = max(int(listing.qty or 1), 1)
    total_oz = oz_per * qty
    melt = total_oz * float(spot)
    pawn_payout = melt * (float(pawn_pct) / 100.0 if pawn_pct > 1.0 else float(pawn_pct))

    total = float(listing.total)
    profit = pawn_payout - total

    # Recommended max TOTAL such that profit margin vs total is target_margin_pct.
    # Profit margin = (payout - total) / total = target_margin_pct
    # => payout = total * (1 + margin) => total = payout / (1 + margin)
    margin = max(float(target_margin_pct), 0.0) / 100.0
    recmax_total = pawn_payout / (1.0 + margin) if pawn_payout > 0 else 0.0
    if recmax_total < 0:
        recmax_total = 0.0

    return SilverResult(
        oz_per_coin=oz_per,
        total_oz=total_oz,
        melt=melt,
        pawn_payout=pawn_payout,
        profit=profit,
        recmax_total=recmax_total,
    )
