"""
state_store.py

Keeps track of already-seen hits to prevent repeat notifications.
"""
from __future__ import annotations

import json
import os
from typing import Dict, Set

def load_seen(path: str) -> Set[str]:
    if not os.path.exists(path):
        return set()
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        if isinstance(data, dict) and "seen" in data and isinstance(data["seen"], list):
            return set(map(str, data["seen"]))
        if isinstance(data, list):
            return set(map(str, data))
    except Exception:
        return set()
    return set()

def save_seen(path: str, seen: Set[str]) -> None:
    tmp = {"seen": sorted(seen)}
    with open(path, "w", encoding="utf-8") as f:
        json.dump(tmp, f, indent=2, sort_keys=True)

def hit_key(page_name: str, item_id: str, title: str) -> str:
    # Prefer stable item id; fallback to page+title
    item_id = (item_id or "").strip()
    if item_id:
        return f"itm:{item_id}"
    return f"pg:{page_name}|{(title or '').strip()}"
