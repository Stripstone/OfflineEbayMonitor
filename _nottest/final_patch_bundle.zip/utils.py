"""
utils.py - small, pure helpers. Keep dependency surface minimal.
"""
from __future__ import annotations

import re
from datetime import datetime, timedelta
from typing import Optional

_MONEY_RE = re.compile(r"[-+]?\$?\s*([0-9]{1,3}(?:,[0-9]{3})*|[0-9]+)(?:\.([0-9]{1,2}))?")

def parse_money(text: str) -> Optional[float]:
    """
    Parses strings like '$12.34', '12.34', 'US $1,234.56', 'Free'.
    Returns None if it can't parse a number.
    """
    if not text:
        return None
    t = text.strip().lower()
    if "free" in t:
        return 0.0
    m = _MONEY_RE.search(text)
    if not m:
        return None
    whole = m.group(1).replace(",", "")
    frac = (m.group(2) or "0").ljust(2, "0")[:2]
    try:
        return float(f"{int(whole)}.{frac}")
    except Exception:
        return None

_TIME_PART_RE = re.compile(r"(\d+)\s*([dhms])", re.I)

def parse_time_left_to_timedelta(text: str) -> Optional[timedelta]:
    """
    Best-effort parse for '3d 4h', '1h 22m', '36s', etc.
    """
    if not text:
        return None
    parts = _TIME_PART_RE.findall(text)
    if not parts:
        return None
    sec = 0
    for n, unit in parts:
        n = int(n)
        unit = unit.lower()
        if unit == "d":
            sec += n * 86400
        elif unit == "h":
            sec += n * 3600
        elif unit == "m":
            sec += n * 60
        elif unit == "s":
            sec += n
    return timedelta(seconds=sec)

def safe_now() -> datetime:
    return datetime.now()
