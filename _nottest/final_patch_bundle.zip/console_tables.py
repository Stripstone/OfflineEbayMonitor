"""
console_tables.py

Console UX table output (contract-aligned columns).
"""
from __future__ import annotations

from typing import Iterable, List

from model_types import HitRow

def _clip(s: str, width: int) -> str:
    s = s or ""
    if len(s) <= width:
        return s
    if width <= 3:
        return s[:width]
    return s[:width-3] + "..."

def render_table(rows: Iterable[HitRow]) -> str:
    rows = list(rows)
    header = "Title                | Hit!/Miss | Found   | Profit     | RecMax     | Total     | Qty | Time Left"
    sep = "-" * max(len(header), 110)

    lines: List[str] = []
    lines.append("HIT!/Miss")
    lines.append(header)
    lines.append(sep)

    for r in rows:
        title = _clip(r.title, 27).ljust(27)
        hm = _clip(r.hit_miss, 9).ljust(9)
        found = f"{r.found_pct:.1f}%".ljust(7)
        profit = f"${r.profit:,.2f}".rjust(9)
        recmax = f"${r.recmax_total:,.2f}".rjust(9)
        total = f"${r.total:,.2f}".rjust(9)
        qty = str(r.qty).ljust(3)
        tl = _clip(r.time_left, 22)

        lines.append(f"{title} | {hm} | {found} | {profit}   | {recmax}   | {total}   | {qty} | {tl}")

    if not rows:
        lines.append("(none)")

    return "\n".join(lines)
