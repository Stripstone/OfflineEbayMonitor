"""
ebay_search_parser.py

Parses an OFFLINE saved eBay search results HTML page into Listing objects.

Goals:
- Be resilient: eBay HTML varies over time.
- Prefer extracting title, url, item price, shipping, time-left.
- Quantity is heuristic from title (lot of X, X coins, roll of 20, etc.)
"""
from __future__ import annotations

import os
import re
from typing import List, Optional

from bs4 import BeautifulSoup

from model_types import Listing
from utils import parse_money

_RE_ITEM_ID = re.compile(r"/itm/(?:[^/]+/)?(\d{9,})")
_RE_QTY = re.compile(r"\b(?:lot of|lot|x|qty|quantity)\s*(\d{1,3})\b", re.I)
_RE_ROLL = re.compile(r"\broll\b.*?\b(\d{1,3})\b", re.I)
_RE_COINS = re.compile(r"\b(\d{1,3})\s*(?:coins?|morgans?|peace|halves|half dollars?)\b", re.I)

def _extract_item_id(url: str) -> Optional[str]:
    if not url:
        return None
    m = _RE_ITEM_ID.search(url)
    return m.group(1) if m else None

def _guess_qty(title: str) -> int:
    t = title or ""
    for rx in (_RE_ROLL, _RE_QTY, _RE_COINS):
        m = rx.search(t)
        if m:
            try:
                q = int(m.group(1))
                if 1 <= q <= 500:
                    return q
            except Exception:
                pass
    return 1

def parse_search_results_html(html_text: str, page_name: str) -> List[Listing]:
    soup = BeautifulSoup(html_text, "lxml")
    listings: List[Listing] = []

    # Common container candidates: li.s-item (classic), div.s-item, etc.
    items = soup.select("li.s-item") or soup.select("div.s-item") or []
    if not items:
        # fallback: any link that looks like /itm/
        items = soup.select("a[href*='/itm/']")

    for node in items:
        # Find best anchor (title + href)
        a = node.select_one("a.s-item__link") or node.find("a", href=True)
        if not a:
            continue
        url = (a.get("href") or "").strip()
        title = (a.get_text(" ", strip=True) or "").strip()

        # sometimes title is in h3 within node
        h3 = node.select_one("h3.s-item__title")
        if h3:
            ht = h3.get_text(" ", strip=True)
            if ht and ht.lower() not in ("shop on ebay", "results matching fewer words"):
                title = ht

        if not url or not title:
            continue
        if "ebay.com" not in url and "/itm/" not in url:
            continue

        # price
        price_text = ""
        p = node.select_one(".s-item__price") or node.select_one("[class*='price']")
        if p:
            price_text = p.get_text(" ", strip=True)
        price = parse_money(price_text) or 0.0

        # shipping
        ship_text = ""
        s = node.select_one(".s-item__shipping") or node.select_one(".s-item__logisticsCost") or node.select_one("[class*='shipping']")
        if s:
            ship_text = s.get_text(" ", strip=True)
        shipping = parse_money(ship_text)
        if shipping is None:
            # 'Free shipping' or missing -> 0
            shipping = 0.0

        # time-left
        time_left = ""
        tl = node.select_one(".s-item__time-left") or node.find(string=re.compile(r"left", re.I))
        if tl:
            time_left = tl.get_text(" ", strip=True) if hasattr(tl, "get_text") else str(tl).strip()

        total = float(price) + float(shipping)
        item_id = _extract_item_id(url)
        qty = _guess_qty(title)

        listings.append(Listing(
            page_name=page_name,
            item_id=item_id,
            url=url,
            title=title,
            price=float(price),
            shipping=float(shipping),
            total=float(total),
            qty=qty,
            time_left_text=time_left,
            ends_at=None,
        ))

    return listings

def parse_file(path: str) -> List[Listing]:
    page_name = os.path.basename(path)
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        html = f.read()
    return parse_search_results_html(html, page_name=page_name)
