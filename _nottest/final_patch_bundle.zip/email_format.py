"""
email_format.py

Builds the email subject/body in a compact, consistent format.
This is intentionally conservative and only includes NEW HITs.
"""
from __future__ import annotations

from datetime import datetime
from typing import List, Optional

from model_types import HitRow

def build_email_subject(earliest_time_left: str, new_hits_count: int) -> str:
    # Example: "10:38 PM Offline eBay Silver HITS (1 new)"
    now = datetime.now().strftime("%I:%M %p").lstrip("0")
    tl = (earliest_time_left or "").strip()
    tl_part = now if not tl else now  # subject uses earliest expiration time in your contract; keep now if unknown
    return f"{tl_part} Offline eBay Silver HITS ({new_hits_count} new)"

def build_email_body(*, spot: float, pawn_pct: float, bid_offset: float, min_margin_pct: float, max_margin_pct: float, max_time_left_hours: float, new_hits: List[HitRow]) -> str:
    lines: List[str] = []
    lines.append("EBAY OFFLINE SILVER HITS")
    lines.append("================================")
    lines.append(f"Spot: ${spot:.2f} | Pawn: {pawn_pct:.1f}%")
    lines.append(f"Bid offset: ${bid_offset:.2f}")
    lines.append(f"Target margin: {min_margin_pct:.1f}%–{max_margin_pct:.1f}%")
    lines.append(f"Max time left: {max_time_left_hours:.2f} hours")
    lines.append("")
    lines.append(f"Total HITs: {len(new_hits)}")
    lines.append("----------------------------------------")
    lines.append("")

    for i, r in enumerate(new_hits, start=1):
        lines.append(f"#{i} [{r.page_name}]")
        lines.append(f"Title: {r.title}")
        lines.append(f"Current Profit: ${r.profit:,.2f}")
        lines.append(f"RecMaxTotal (incl. ship): ${r.recmax_total:,.2f}")
        lines.append(f"Current Total: ${r.total:,.2f}")
        lines.append(f"Qty: {r.qty} | oz/coin: {r.oz_per_coin:.5f} | Total oz: {r.total_oz:.2f}")
        lines.append(f"Melt: ${r.melt:,.2f} | Pawn payout: ${r.pawn_payout:,.2f}")
        lines.append(f"Time left: {r.time_left}")
        if r.url:
            lines.append(f"Links: {r.url}")
        lines.append("")

    return "\n".join(lines).rstrip() + "\n"
