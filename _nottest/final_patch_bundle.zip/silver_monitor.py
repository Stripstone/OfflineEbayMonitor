"""
silver_monitor.py

Main loop:
- Scan folder for saved eBay HTML pages (search results pages).
- Parse listings.
- Evaluate hits.
- Print console table.
- Email only NEW HITs.
- Optionally delete processed HTML files.

This patch intentionally avoids requiring new config constants; it uses safe fallbacks.
"""
from __future__ import annotations

import os
import time
from datetime import datetime
from typing import List

import config

from ebay_search_parser import parse_file
from hit_engine import evaluate_listings
from console_tables import render_table
from email_format import build_email_body, build_email_subject
from emailer import send_email_if_needed
from state_store import load_seen, save_seen, hit_key

def _get(name: str, default=None):
    return getattr(config, name, default)

def scan_folder(folder: str) -> List[str]:
    if not folder or not os.path.isdir(folder):
        return []
    return [
        os.path.join(folder, fn)
        for fn in os.listdir(folder)
        if fn.lower().endswith(".html")
    ]

def main() -> None:
    print("=" * 52)
    print("  EBAY OFFLINE SILVER MONITOR")
    print("=" * 52)

    folder = _get("HTML_FOLDER_PATH") or _get("HTML_FOLDER") or _get("SCAN_FOLDER") or ""
    delete_after = bool(_get("DELETE_AFTER_PROCESS", True))

    spot = float(_get("SPOT_PRICE", 60.0))
    pawn_pct = float(_get("PAWN_PAYOUT_PCT", 0.90))
    # allow both 0.90 or 90.0
    if pawn_pct > 1.5:
        pawn_pct = pawn_pct / 100.0

    min_margin = float(_get("TARGET_MARGIN_MIN_PCT", 10.0))
    max_margin = float(_get("TARGET_MARGIN_MAX_PCT", 60.0))
    bid_offset = float(_get("BID_OFFSET", 0.0))
    email_enabled = bool(_get("EMAIL_ENABLED", True))

    seen_path = _get("SEEN_HITS_PATH", os.path.join(os.getcwd(), "seen_hits.json"))
    seen = load_seen(seen_path)

    # Sleep config: accept multiple naming styles
    sleep_seconds = _get("SCAN_SLEEP_SECONDS", None)
    if sleep_seconds is None:
        interval_min = _get("CHECK_INTERVAL_MINUTES", None)
        if interval_min is None:
            interval_min = _get("SCAN_INTERVAL_MINUTES", None)
        if interval_min is None:
            interval_min = 1.0
        sleep_seconds = float(interval_min) * 60.0

    max_time_left_hours = float(_get("MAX_TIME_LEFT_HOURS", 24.0))

    while True:
        paths = scan_folder(folder)
        all_listings = []
        processed = 0

        for p in paths:
            try:
                listings = parse_file(p)
                all_listings.extend(listings)
                processed += 1
                if delete_after:
                    try:
                        os.remove(p)
                    except Exception:
                        pass
            except Exception as e:
                print(f"[WARN] Failed parsing {os.path.basename(p)}: {e}")

        hits, rows = evaluate_listings(
            all_listings,
            spot=spot,
            pawn_pct=pawn_pct,
            min_margin_pct=min_margin,
            max_margin_pct=max_margin,
        )

        # Determine NEW hits
        new_hits = []
        for h in hits:
            key = hit_key(h.page_name, h.item_id, h.title)
            if key not in seen:
                seen.add(key)
                new_hits.append(h)

        ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        print(f"\n[{ts}] Files: {processed} | Listings: {len(all_listings)} | HITs: {len(hits)} | New: {len(new_hits)}")
        print("")
        print(render_table(rows))

        if new_hits:
            earliest = new_hits[0].time_left or ""
            subject = build_email_subject(earliest, len(new_hits))
            body = build_email_body(
                spot=spot,
                pawn_pct=pawn_pct * 100.0,  # display percent
                bid_offset=bid_offset,
                min_margin_pct=min_margin,
                max_margin_pct=max_margin,
                max_time_left_hours=max_time_left_hours,
                new_hits=new_hits,
            )
            try:
                sent = send_email_if_needed(subject, body, enabled=email_enabled)
                print("EMAIL: sent" if sent else "EMAIL: disabled")
            except Exception as e:
                print(f"[ERROR] Email send failed: {e}")
        else:
            print("EMAIL: (no new HITs)")

        save_seen(seen_path, seen)
        time.sleep(float(sleep_seconds))

if __name__ == "__main__":
    main()
