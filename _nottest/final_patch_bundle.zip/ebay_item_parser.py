"""
ebay_item_parser.py

This patch focuses on parsing search-result pages.
If you later add item-page parsing, put it here.
"""
