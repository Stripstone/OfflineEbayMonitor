"""
emailer.py

Sends email using SMTP config. This file expects your config.py to provide:
- SMTP_HOST, SMTP_PORT, SMTP_USERNAME, SMTP_PASSWORD
- EMAIL_FROM, EMAIL_TO
Optionally:
- SMTP_USE_TLS (bool)
"""
from __future__ import annotations

import smtplib
from email.message import EmailMessage
from typing import Optional

import config

def _get(name: str, default=None):
    return getattr(config, name, default)

def send_email(subject: str, body: str) -> None:
    host = _get("SMTP_HOST")
    port = int(_get("SMTP_PORT", 587))
    user = _get("SMTP_USERNAME")
    pwd = _get("SMTP_PASSWORD")
    mail_from = _get("EMAIL_FROM")
    mail_to = _get("EMAIL_TO")
    use_tls = bool(_get("SMTP_USE_TLS", True))

    if not (host and mail_from and mail_to):
        raise RuntimeError("SMTP config missing (SMTP_HOST/EMAIL_FROM/EMAIL_TO).")

    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = mail_from
    msg["To"] = mail_to
    msg.set_content(body)

    with smtplib.SMTP(host, port, timeout=20) as s:
        if use_tls:
            s.starttls()
        if user and pwd:
            s.login(user, pwd)
        s.send_message(msg)

def send_email_if_needed(subject: str, body: str, *, enabled: bool) -> bool:
    if not enabled:
        return False
    send_email(subject, body)
    return True
