"""
hit_engine.py

Evaluates Listing -> HitRow using silver_math + config thresholds.

This is a simplified, stable engine intended to stop the "endless patch" spiral:
- If a listing is not confidently silver, we skip it entirely (no spam rows).
- If it is silver, we compute melt, pawn payout, profit, and recommended max.
"""
from __future__ import annotations

from typing import List, Tuple

from model_types import Listing, HitRow
from silver_math import calc_silver

def evaluate_listings(listings: List[Listing], *, spot: float, pawn_pct: float, min_margin_pct: float, max_margin_pct: float) -> Tuple[List[HitRow], List[HitRow]]:
    hits: List[HitRow] = []
    all_rows: List[HitRow] = []

    for lst in listings:
        res = calc_silver(lst, spot=spot, pawn_pct=pawn_pct, target_margin_pct=min_margin_pct)
        if res is None:
            continue  # ignore non-silver / unknown

        profit = res.profit
        total = float(lst.total)
        margin = (profit / total * 100.0) if total > 0 else -999.0

        hit = (profit > 0) and (margin >= float(min_margin_pct)) and (margin <= float(max_margin_pct))

        row = HitRow(
            title=lst.title,
            hit_miss="HIT" if hit else "Miss",
            found_pct=0.0,
            profit=float(profit),
            recmax_total=float(res.recmax_total),
            total=float(total),
            qty=int(lst.qty or 1),
            time_left=(lst.time_left_text or ""),
            page_name=lst.page_name,
            url=lst.url,
            item_id=str(lst.item_id or ""),
            melt=float(res.melt),
            pawn_payout=float(res.pawn_payout),
            oz_per_coin=float(res.oz_per_coin),
            total_oz=float(res.total_oz),
        )
        all_rows.append(row)
        if hit:
            hits.append(row)

    # sort for UX: soonest expiry first is ideal; if time_left_text isn't parseable, keep stable by title
    # (email_format will also pick earliest text if available)
    return hits, all_rows
